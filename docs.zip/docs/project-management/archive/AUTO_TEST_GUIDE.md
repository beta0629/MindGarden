# 자동화 테스트 실행 가이드

## 개요

AI가 자동으로 모든 테스트 케이스를 실행하고 결과를 리포트로 생성하는 가이드입니다.

## 🚀 빠른 시작

### 1. Week 4 ERD 기능 테스트 (권장)

```bash
./scripts/run-week4-tests.sh
```

**실행 내용:**
- ERD 컨트롤러 통합 테스트
- ERD 생성 서비스 통합 테스트
- 온보딩 승인 서비스 통합 테스트
- 모든 ERD 관련 테스트

**결과:**
- 리포트: `test-reports/week4-erd/{timestamp}/week4-test-summary.md`
- 상세 로그: `test-reports/week4-erd/{timestamp}/*.log`

### 2. 전체 테스트 실행

```bash
./scripts/run-all-tests.sh
```

**실행 내용:**
- 모든 백엔드 통합 테스트
- API 테스트 (서버 실행 중일 때)
- 프론트엔드 테스트 (있는 경우)

**전체 테스트 실행 (시간 소요):**
```bash
./scripts/run-all-tests.sh --full
```

### 3. API 테스트만 실행

```bash
./scripts/run-api-tests.sh
```

**전제 조건:**
- 서버가 실행 중이어야 함 (`http://localhost:8080`)

**실행 내용:**
- Health Check API
- ERD 목록 조회 API
- 공통코드 API
- Swagger UI 접근 확인

## 📊 테스트 결과 확인

### 리포트 위치

모든 테스트 리포트는 `test-reports/` 디렉토리에 저장됩니다:

```
test-reports/
├── week4-erd/
│   └── {timestamp}/
│       ├── week4-test-summary.md
│       ├── erd-controller.log
│       ├── erd-generation-service.log
│       └── ...
├── api-tests/
│   └── {timestamp}/
│       ├── api-test-summary.md
│       └── *.json
└── {timestamp}/
    └── test-summary.md
```

### 리포트 내용

각 리포트는 다음 정보를 포함합니다:

1. **테스트 결과 요약**
   - 통과/실패 개수
   - 성공률
   - 실행 시간

2. **실행된 테스트 목록**
   - 각 테스트의 이름과 상태

3. **상세 로그 링크**
   - 각 테스트의 상세 로그 파일 위치

4. **다음 단계**
   - 실패한 테스트 수정 방법
   - 재실행 방법

## 🔄 CI/CD 통합

### GitHub Actions 예시

```yaml
name: Automated Tests

on:
  push:
    branches: [ main, develop ]
  pull_request:
    branches: [ main ]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Set up JDK 17
        uses: actions/setup-java@v3
        with:
          java-version: '17'
      - name: Run Week 4 ERD Tests
        run: ./scripts/run-week4-tests.sh
      - name: Upload Test Reports
        uses: actions/upload-artifact@v3
        with:
          name: test-reports
          path: test-reports/
```

## 📝 테스트 커버리지

### 현재 커버리지

- ✅ ERD 컨트롤러 통합 테스트
- ✅ ERD 생성 서비스 통합 테스트
- ✅ 온보딩 승인 서비스 통합 테스트
- ✅ PG 설정 컨트롤러 통합 테스트
- ✅ API 엔드포인트 테스트

### 향후 추가 예정

- [ ] 프론트엔드 E2E 테스트 (Playwright/Cypress)
- [ ] 성능 테스트 (JMeter/Gatling)
- [ ] 보안 테스트 (OWASP ZAP)
- [ ] 시각적 회귀 테스트 (Percy/Chromatic)

## 🛠️ 문제 해결

### 테스트 실행 실패

1. **서버가 실행 중이 아닌 경우**
   ```bash
   ./scripts/start-backend.sh local
   ```

2. **데이터베이스 연결 오류**
   - `application-local.yml` 또는 환경 변수 확인
   - 데이터베이스가 실행 중인지 확인

3. **포트 충돌**
   ```bash
   lsof -ti:8080 | xargs kill -9
   ```

### 테스트 결과 해석

- **✅ 통과**: 테스트가 성공적으로 완료됨
- **❌ 실패**: 테스트 실패, 로그 파일 확인 필요
- **⚠️ 건너뜀**: 전제 조건 미충족 (예: 서버 미실행)

## 📚 관련 문서

- 빠른 테스트 가이드: `docs/mgsb/WEEK4_QUICK_TEST_GUIDE.md`
- 상세 테스트 가이드: `docs/mgsb/WEEK4_TESTING_GUIDE.md`
- 테스트 전략: `docs/mgsb/PHASE1_QA_TEST_STRATEGY.md`

## 🎯 권장 실행 순서

1. **개발 중**: `./scripts/run-week4-tests.sh` (빠른 피드백)
2. **커밋 전**: `./scripts/run-all-tests.sh` (전체 검증)
3. **배포 전**: `./scripts/run-all-tests.sh --full` (완전한 검증)

