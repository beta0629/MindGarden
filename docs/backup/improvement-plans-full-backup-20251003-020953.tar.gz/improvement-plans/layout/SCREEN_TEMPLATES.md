# 화면 템플릿 가이드

## 개요
MindGarden 프로젝트의 주요 화면별 레이아웃 템플릿과 반응형 디자인 패턴을 정의합니다.

## 템플릿 구조

### 1. 기본 페이지 템플릿

```jsx
const BasePageTemplate = ({ 
  title, 
  subtitle, 
  children, 
  actions,
  layout = 'default' 
}) => (
  <div className={`page-template page-template--${layout}`}>
    {/* 페이지 헤더 */}
    <header className="page-header">
      <div className="page-header__content">
        <div className="page-header__title">
          <h1 className="page-title">{title}</h1>
          {subtitle && <p className="page-subtitle">{subtitle}</p>}
        </div>
        {actions && (
          <div className="page-header__actions">
            {actions}
          </div>
        )}
      </div>
    </header>

    {/* 페이지 컨텐츠 */}
    <main className="page-main">
      <div className="page-container">
        {children}
      </div>
    </main>
  </div>
);
```

### 2. 대시보드 템플릿

```jsx
const DashboardTemplate = ({ stats, charts, recent, quickActions }) => (
  <BasePageTemplate 
    title="대시보드" 
    subtitle="시스템 현황 및 주요 지표"
    layout="dashboard"
  >
    {/* 통계 카드 섹션 */}
    <section className="dashboard-section dashboard-section--stats">
      <div className="stats-grid">
        {stats.map((stat, index) => (
          <StatCard key={index} {...stat} />
        ))}
      </div>
    </section>

    {/* 차트 섹션 */}
    {charts && (
      <section className="dashboard-section dashboard-section--charts">
        <div className="charts-grid">
          {charts.map((chart, index) => (
            <ChartCard key={index} {...chart} />
          ))}
        </div>
      </section>
    )}

    {/* 최근 활동 섹션 */}
    {recent && (
      <section className="dashboard-section dashboard-section--recent">
        <RecentActivityCard {...recent} />
      </section>
    )}

    {/* 빠른 액션 섹션 */}
    {quickActions && (
      <section className="dashboard-section dashboard-section--actions">
        <QuickActionsGrid actions={quickActions} />
      </section>
    )}
  </BasePageTemplate>
);
```

### 3. 관리 페이지 템플릿

```jsx
const ManagementTemplate = ({ 
  title, 
  subtitle, 
  searchFilters, 
  data, 
  actions,
  onSearch,
  onFilter 
}) => (
  <BasePageTemplate title={title} subtitle={subtitle} layout="management">
    {/* 검색 및 필터 섹션 */}
    <section className="management-section management-section--filters">
      <SearchFilterBar 
        filters={searchFilters}
        onSearch={onSearch}
        onFilter={onFilter}
      />
    </section>

    {/* 데이터 그리드 섹션 */}
    <section className="management-section management-section--data">
      <DataGrid 
        data={data}
        actions={actions}
      />
    </section>
  </BasePageTemplate>
);
```

### 4. 폼 페이지 템플릿

```jsx
const FormTemplate = ({ 
  title, 
  subtitle, 
  form, 
  actions,
  layout = 'single-column' 
}) => (
  <BasePageTemplate title={title} subtitle={subtitle} layout="form">
    <div className={`form-container form-container--${layout}`}>
      <div className="form-wrapper">
        {form}
        
        {/* 폼 액션 버튼 */}
        <div className="form-actions">
          {actions}
        </div>
      </div>
    </div>
  </BasePageTemplate>
);
```

## 레이아웃 패턴

### 1. 모바일 레이아웃 패턴

#### 세로 스택 레이아웃
```css
.mobile-layout--stack {
  display: flex;
  flex-direction: column;
  gap: var(--spacing-sm);
}

.mobile-layout--stack .card {
  width: 100%;
  margin-bottom: var(--spacing-sm);
}
```

#### 2열 그리드 레이아웃
```css
.mobile-layout--grid-2 {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: var(--spacing-sm);
}

.mobile-layout--grid-2 .card {
  min-height: 120px;
}
```

#### 탭 레이아웃
```css
.mobile-layout--tabs {
  display: flex;
  flex-direction: column;
  height: 100vh;
}

.mobile-layout--tabs .tab-content {
  flex: 1;
  overflow-y: auto;
  padding: var(--spacing-md);
}
```

### 2. 태블릿 레이아웃 패턴

#### 사이드바 레이아웃
```css
.tablet-layout--sidebar {
  display: grid;
  grid-template-columns: 250px 1fr;
  gap: var(--spacing-md);
  height: 100vh;
}

.tablet-layout--sidebar .sidebar {
  background: var(--color-surface);
  padding: var(--spacing-md);
  overflow-y: auto;
}

.tablet-layout--sidebar .main-content {
  padding: var(--spacing-md);
  overflow-y: auto;
}
```

#### 2열 그리드 레이아웃
```css
.tablet-layout--grid-2 {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: var(--spacing-md);
}

.tablet-layout--grid-2 .card {
  min-height: 200px;
}
```

### 3. 데스크톱 레이아웃 패턴

#### 3열 그리드 레이아웃
```css
.desktop-layout--grid-3 {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: var(--spacing-lg);
}

.desktop-layout--grid-3 .card {
  min-height: 250px;
}
```

#### 마스터-디테일 레이아웃
```css
.desktop-layout--master-detail {
  display: grid;
  grid-template-columns: 400px 1fr;
  gap: var(--spacing-lg);
  height: 100vh;
}

.desktop-layout--master-detail .master-panel {
  background: var(--color-surface);
  border-right: 1px solid var(--color-border);
  overflow-y: auto;
}

.desktop-layout--master-detail .detail-panel {
  padding: var(--spacing-lg);
  overflow-y: auto;
}
```

## 컴포넌트별 레이아웃

### 1. 카드 컴포넌트 레이아웃

#### 기본 카드
```css
.card {
  background: var(--color-surface);
  border-radius: var(--border-radius-md);
  padding: var(--spacing-md);
  box-shadow: var(--shadow-sm);
  transition: var(--transition-base);
}

.card:hover {
  box-shadow: var(--shadow-md);
  transform: translateY(-2px);
}
```

#### 통계 카드
```css
.stat-card {
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  padding: var(--spacing-lg);
  background: var(--color-surface);
  border-radius: var(--border-radius-md);
  box-shadow: var(--shadow-sm);
}

.stat-card__icon {
  width: 48px;
  height: 48px;
  border-radius: var(--border-radius-full);
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: var(--spacing-sm);
}

.stat-card__value {
  font-size: var(--font-size-2xl);
  font-weight: var(--font-weight-bold);
  color: var(--color-primary);
  margin-bottom: var(--spacing-xs);
}

.stat-card__label {
  font-size: var(--font-size-sm);
  color: var(--color-text-secondary);
}
```

#### 액션 카드
```css
.action-card {
  display: flex;
  align-items: center;
  padding: var(--spacing-md);
  background: var(--color-surface);
  border-radius: var(--border-radius-md);
  box-shadow: var(--shadow-sm);
  cursor: pointer;
  transition: var(--transition-base);
}

.action-card:hover {
  background: var(--color-surface-hover);
  box-shadow: var(--shadow-md);
}

.action-card__icon {
  width: 40px;
  height: 40px;
  border-radius: var(--border-radius-md);
  display: flex;
  align-items: center;
  justify-content: center;
  margin-right: var(--spacing-md);
}

.action-card__content {
  flex: 1;
}

.action-card__title {
  font-size: var(--font-size-base);
  font-weight: var(--font-weight-medium);
  margin-bottom: var(--spacing-xs);
}

.action-card__description {
  font-size: var(--font-size-sm);
  color: var(--color-text-secondary);
}
```

### 2. 폼 컴포넌트 레이아웃

#### 기본 폼
```css
.form {
  display: flex;
  flex-direction: column;
  gap: var(--spacing-md);
}

.form-row {
  display: grid;
  gap: var(--spacing-md);
}

.form-row--2 {
  grid-template-columns: repeat(2, 1fr);
}

.form-row--3 {
  grid-template-columns: repeat(3, 1fr);
}

.form-group {
  display: flex;
  flex-direction: column;
  gap: var(--spacing-xs);
}

.form-label {
  font-size: var(--font-size-sm);
  font-weight: var(--font-weight-medium);
  color: var(--color-text-primary);
}

.form-input {
  padding: var(--spacing-sm) var(--spacing-md);
  border: 1px solid var(--color-border);
  border-radius: var(--border-radius-sm);
  font-size: var(--font-size-base);
  transition: var(--transition-base);
}

.form-input:focus {
  outline: none;
  border-color: var(--color-primary);
  box-shadow: 0 0 0 3px var(--color-primary-light);
}
```

#### 인라인 폼
```css
.form-inline {
  display: flex;
  align-items: end;
  gap: var(--spacing-sm);
}

.form-inline .form-group {
  flex: 1;
}

.form-inline .form-actions {
  flex-shrink: 0;
}
```

## 반응형 동작

### 1. 모바일 (≤ 768px)
- **레이아웃**: 세로 스택 또는 2열 그리드
- **폰트 크기**: 기본 크기 유지
- **여백**: 축소된 여백
- **터치 영역**: 최소 44px × 44px

### 2. 태블릿 (769px - 1024px)
- **레이아웃**: 2열 그리드 또는 사이드바
- **폰트 크기**: 기본 크기
- **여백**: 표준 여백
- **인터랙션**: 터치 + 마우스 지원

### 3. 데스크톱 (≥ 1025px)
- **레이아웃**: 3-4열 그리드 또는 복합 레이아웃
- **폰트 크기**: 기본 크기
- **여백**: 넉넉한 여백
- **인터랙션**: 마우스 중심

## 접근성 고려사항

### 1. 키보드 네비게이션
- 모든 인터랙티브 요소에 키보드 접근 가능
- 포커스 표시 명확
- Tab 순서 논리적

### 2. 스크린 리더 지원
- 의미있는 HTML 구조
- 적절한 ARIA 레이블
- 상태 변화 알림

### 3. 시각적 접근성
- 충분한 색상 대비
- 텍스트 크기 조절 가능
- 고대비 모드 지원

## 성능 최적화

### 1. 레이아웃 최적화
- CSS Grid/Flexbox 활용
- 레이아웃 시프트 최소화
- 가상화 적용 (긴 리스트)

### 2. 렌더링 최적화
- Critical CSS 분리
- 지연 로딩 구현
- 이미지 최적화

### 3. 번들 최적화
- 컴포넌트별 코드 스플리팅
- 동적 임포트 활용
- 트리 셰이킹 적용

## 사용 예시

### 1. 회기 관리 페이지
```jsx
const SessionManagementPage = () => (
  <ManagementTemplate
    title="회기 관리"
    subtitle="내담자의 상담 회기를 등록하고 관리"
    searchFilters={[
      { type: 'search', placeholder: '내담자 검색...' },
      { type: 'select', options: ['전체', '활성', '비활성'] }
    ]}
    data={sessionData}
    actions={sessionActions}
  />
);
```

### 2. 대시보드 페이지
```jsx
const AdminDashboard = () => (
  <DashboardTemplate
    stats={dashboardStats}
    charts={dashboardCharts}
    recent={recentActivities}
    quickActions={quickActionItems}
  />
);
```

### 3. 사용자 등록 폼
```jsx
const UserRegistrationForm = () => (
  <FormTemplate
    title="사용자 등록"
    subtitle="새로운 사용자 계정을 생성합니다"
    form={<UserRegistrationFormFields />}
    actions={<FormActionButtons />}
    layout="two-column"
  />
);
```

## 마이그레이션 가이드

### 1. 기존 컴포넌트 업데이트
1. 템플릿 구조 적용
2. 레이아웃 클래스 추가
3. 반응형 스타일 적용

### 2. 새로운 컴포넌트 개발
1. 템플릿 기반 구조 사용
2. 표준 레이아웃 패턴 적용
3. 접근성 가이드라인 준수

### 3. 테스트 및 검증
1. 반응형 테스트
2. 접근성 테스트
3. 성능 테스트
