# 컴포넌트 템플릿 표준

**버전**: 1.0.0  
**최종 업데이트**: 2025-12-03  
**상태**: 공식 표준

---

## 📌 개요

MindGarden 프로젝트의 컴포넌트 템플릿 표준입니다.  
기본 템플릿에서 비즈니스 로직만 작성하면 되도록 공통화 전략을 정의합니다.

### 참조 문서
- [프론트엔드 개발 표준](./FRONTEND_DEVELOPMENT_STANDARD.md)
- [화면 컴포넌트 구성 표준](./COMPONENT_STRUCTURE_STANDARD.md)
- [API 연동 표준](./API_INTEGRATION_STANDARD.md)

### 구현 위치
- **페이지 템플릿**: `frontend/src/components/layout/SimpleLayout.js`
- **폼 템플릿**: `frontend/src/components/common/MGForm.js`
- **테이블 템플릿**: `frontend/src/components/common/MGTable.js`
- **위젯 템플릿**: `frontend/src/components/dashboard/widgets/BaseWidget.js`
- **모달 템플릿**: `frontend/src/components/common/modals/BaseModal.js`
- **로딩 컴포넌트**: `frontend/src/components/common/UnifiedLoading.js`

---

## 🎯 컴포넌트 템플릿 원칙

### 1. 템플릿 기반 개발
```
기본 템플릿을 사용하고 비즈니스 로직만 작성
```

**원칙**:
- ✅ 표준 템플릿 사용
- ✅ 공통 처리 자동화 (로딩, 에러, 빈 상태 등)
- ✅ 비즈니스 로직만 작성
- ✅ 레이아웃 및 구조는 템플릿에 포함
- ❌ 템플릿 없이 처음부터 작성 금지

### 2. 공통 처리 자동화
```
로딩, 에러, 빈 상태 등은 템플릿에서 자동 처리
```

**원칙**:
- ✅ 로딩 상태 자동 표시
- ✅ 에러 상태 자동 처리
- ✅ 빈 데이터 상태 자동 처리
- ✅ 반응형 레이아웃 자동 적용
- ✅ 접근성 속성 자동 추가

### 3. 코드 중복 제거
```
공통 코드는 템플릿에 포함하여 중복 제거
```

**원칙**:
- ✅ 반복되는 패턴은 템플릿화
- ✅ 공통 로직은 템플릿에 포함
- ✅ 스타일은 템플릿에 포함
- ❌ 동일한 패턴 반복 작성 금지

---

## 📋 표준 컴포넌트 템플릿

### 1. 페이지 컴포넌트 템플릿

#### 기본 페이지 템플릿
```javascript
import SimpleLayout from '../layout/SimpleLayout';
import { MGSection, MGContainer } from '../common/MGLayout';
import UnifiedLoading from '../common/UnifiedLoading';

/**
 * 페이지 컴포넌트 템플릿
 * 
 * 사용법:
 * 1. SimpleLayout으로 감싸기
 * 2. 비즈니스 로직만 작성
 * 3. 레이아웃은 템플릿이 자동 처리
 */
const MyPage = () => {
    // ========== 비즈니스 로직 시작 ==========
    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(false);
    
    useEffect(() => {
        // 데이터 로드
        loadData();
    }, []);
    
    const loadData = async () => {
        setLoading(true);
        try {
            // API 호출
            const result = await apiGet('/api/v1/data');
            setData(result);
        } catch (error) {
            // 에러 처리
        } finally {
            setLoading(false);
        }
    };
    // ========== 비즈니스 로직 끝 ==========
    
    return (
        <SimpleLayout title="페이지 제목">
            <MGSection variant="default" padding="medium">
                <MGContainer size="xl">
                    {/* 페이지 내용만 작성 */}
                    <section className="page-content">
                        {loading ? (
                            <UnifiedLoading 
                                type="page"
                                text="데이터를 불러오는 중..."
                                variant="pulse"
                            />
                        ) : (
                            <div>
                                {/* 데이터 표시 */}
                            </div>
                        )}
                    </section>
                </MGContainer>
            </MGSection>
        </SimpleLayout>
    );
};

export default MyPage;
```

### 2. 리스트 컴포넌트 템플릿

#### 기본 리스트 템플릿
```javascript
import SimpleLayout from '../layout/SimpleLayout';
import { MGTable } from '../common/MGTable';
import { Button } from '../ui/Button/Button';
import { apiGet, apiDelete } from '../../utils/ajax';

/**
 * 리스트 컴포넌트 템플릿
 * 
 * 기능:
 * - 데이터 목록 표시
 * - 로딩/에러/빈 상태 자동 처리
 * - 삭제 기능 포함
 */
const ListPage = () => {
    // ========== 비즈니스 로직 시작 ==========
    const [items, setItems] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    
    useEffect(() => {
        loadItems();
    }, []);
    
    const loadItems = async () => {
        setLoading(true);
        setError(null);
        try {
            const response = await apiGet('/api/v1/items');
            setItems(response.data || []);
        } catch (err) {
            setError('데이터를 불러오는데 실패했습니다.');
        } finally {
            setLoading(false);
        }
    };
    
    const handleDelete = async (id) => {
        if (!window.confirm('정말 삭제하시겠습니까?')) return;
        
        try {
            await apiDelete(`/api/v1/items/${id}`);
            await loadItems(); // 목록 새로고침
        } catch (err) {
            notificationManager.error('삭제에 실패했습니다.');
        }
    };
    // ========== 비즈니스 로직 끝 ==========
    
    // 컬럼 정의 (비즈니스 로직)
    const columns = [
        { key: 'name', label: '이름' },
        { key: 'email', label: '이메일' },
        {
            key: 'actions',
            label: '작업',
            render: (value, row) => (
                <Button
                    variant="danger"
                    size="small"
                    onClick={() => handleDelete(row.id)}
                >
                    삭제
                </Button>
            )
        }
    ];
    
    return (
        <SimpleLayout title="목록">
            <MGTable
                columns={columns}
                data={items}
                loading={loading}
                error={error}
                onRowClick={(row) => {
                    // 행 클릭 처리
                }}
            />
        </SimpleLayout>
    );
};

export default ListPage;
```

### 3. 폼 컴포넌트 템플릿

#### 기본 폼 템플릿
```javascript
import SimpleLayout from '../layout/SimpleLayout';
import { MGForm, MGFormInput, MGFormSelect, MGFormTextarea } from '../common/MGForm';
import { Button } from '../ui/Button/Button';
import { apiPost, apiPut } from '../../utils/ajax';
import { useParams, useNavigate } from 'react-router-dom';

/**
 * 폼 컴포넌트 템플릿
 * 
 * 기능:
 * - 폼 입력 처리
 * - 유효성 검사
 * - 제출 처리
 */
const FormPage = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const isEdit = !!id;
    
    // ========== 비즈니스 로직 시작 ==========
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        role: '',
        description: ''
    });
    const [loading, setLoading] = useState(false);
    const [errors, setErrors] = useState({});
    
    useEffect(() => {
        if (isEdit) {
            loadData();
        }
    }, [id]);
    
    const loadData = async () => {
        try {
            const response = await apiGet(`/api/v1/items/${id}`);
            setFormData(response.data);
        } catch (err) {
            notificationManager.error('데이터를 불러오는데 실패했습니다.');
        }
    };
    
    const handleChange = (name, value) => {
        setFormData(prev => ({
            ...prev,
            [name]: value
        }));
        // 에러 초기화
        if (errors[name]) {
            setErrors(prev => ({
                ...prev,
                [name]: ''
            }));
        }
    };
    
    const validate = () => {
        const newErrors = {};
        if (!formData.name) newErrors.name = '이름을 입력하세요.';
        if (!formData.email) newErrors.email = '이메일을 입력하세요.';
        if (!formData.role) newErrors.role = '역할을 선택하세요.';
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };
    
    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!validate()) return;
        
        setLoading(true);
        try {
            if (isEdit) {
                await apiPut(`/api/v1/items/${id}`, formData);
                notificationManager.success('수정되었습니다.');
            } else {
                await apiPost('/api/v1/items', formData);
                notificationManager.success('생성되었습니다.');
            }
            navigate('/items');
        } catch (err) {
            notificationManager.error('저장에 실패했습니다.');
        } finally {
            setLoading(false);
        }
    };
    // ========== 비즈니스 로직 끝 ==========
    
    return (
        <SimpleLayout title={isEdit ? '수정' : '생성'}>
            <MGForm onSubmit={handleSubmit} loading={loading}>
                <MGFormInput
                    label="이름"
                    name="name"
                    value={formData.name}
                    onChange={(e) => handleChange('name', e.target.value)}
                    error={errors.name}
                    required
                />
                
                <MGFormInput
                    label="이메일"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => handleChange('email', e.target.value)}
                    error={errors.email}
                    required
                />
                
                <MGFormSelect
                    label="역할"
                    name="role"
                    value={formData.role}
                    onChange={(e) => handleChange('role', e.target.value)}
                    options={[
                        { value: 'ADMIN', label: '관리자' },
                        { value: 'USER', label: '사용자' }
                    ]}
                    error={errors.role}
                    required
                />
                
                <MGFormTextarea
                    label="설명"
                    name="description"
                    value={formData.description}
                    onChange={(e) => handleChange('description', e.target.value)}
                    rows={4}
                />
                
                <div className="form-actions">
                    <Button
                        type="submit"
                        variant="primary"
                        loading={loading}
                    >
                        {isEdit ? '수정' : '생성'}
                    </Button>
                    
                    <Button
                        type="button"
                        variant="secondary"
                        onClick={() => navigate('/items')}
                    >
                        취소
                    </Button>
                </div>
            </MGForm>
        </SimpleLayout>
    );
};

export default FormPage;
```

### 4. 상세 보기 컴포넌트 템플릿

#### 기본 상세 보기 템플릿
```javascript
import SimpleLayout from '../layout/SimpleLayout';
import { MGCard } from '../common/MGCard';
import { Button } from '../ui/Button/Button';
import { apiGet, apiDelete } from '../../utils/ajax';
import { useParams, useNavigate } from 'react-router-dom';

/**
 * 상세 보기 컴포넌트 템플릿
 * 
 * 기능:
 * - 데이터 상세 표시
 * - 수정/삭제 버튼
 */
const DetailPage = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    
    // ========== 비즈니스 로직 시작 ==========
    const [item, setItem] = useState(null);
    const [loading, setLoading] = useState(false);
    
    useEffect(() => {
        loadData();
    }, [id]);
    
    const loadData = async () => {
        setLoading(true);
        try {
            const response = await apiGet(`/api/v1/items/${id}`);
            setItem(response.data);
        } catch (err) {
            notificationManager.error('데이터를 불러오는데 실패했습니다.');
            navigate('/items');
        } finally {
            setLoading(false);
        }
    };
    
    const handleDelete = async () => {
        if (!window.confirm('정말 삭제하시겠습니까?')) return;
        
        try {
            await apiDelete(`/api/v1/items/${id}`);
            notificationManager.success('삭제되었습니다.');
            navigate('/items');
        } catch (err) {
            notificationManager.error('삭제에 실패했습니다.');
        }
    };
    // ========== 비즈니스 로직 끝 ==========
    
    if (loading) {
        return (
            <SimpleLayout title="로딩 중...">
                <div>로딩 중...</div>
            </SimpleLayout>
        );
    }
    
    if (!item) {
        return (
            <SimpleLayout title="데이터 없음">
                <div>데이터를 찾을 수 없습니다.</div>
            </SimpleLayout>
        );
    }
    
    return (
        <SimpleLayout title="상세 보기">
            <MGCard>
                <div className="detail-content">
                    <div className="detail-row">
                        <label>이름:</label>
                        <span>{item.name}</span>
                    </div>
                    
                    <div className="detail-row">
                        <label>이메일:</label>
                        <span>{item.email}</span>
                    </div>
                    
                    <div className="detail-row">
                        <label>역할:</label>
                        <span>{item.role}</span>
                    </div>
                </div>
                
                <div className="detail-actions">
                    <Button
                        variant="primary"
                        onClick={() => navigate(`/items/${id}/edit`)}
                    >
                        수정
                    </Button>
                    
                    <Button
                        variant="danger"
                        onClick={handleDelete}
                    >
                        삭제
                    </Button>
                    
                    <Button
                        variant="secondary"
                        onClick={() => navigate('/items')}
                    >
                        목록으로
                    </Button>
                </div>
            </MGCard>
        </SimpleLayout>
    );
};

export default DetailPage;
```

### 5. 위젯 컴포넌트 템플릿

#### 기본 위젯 템플릿
```javascript
import BaseWidget from './BaseWidget';
import { useWidget } from '../../../hooks/useWidget';

/**
 * 위젯 컴포넌트 템플릿
 * 
 * 기능:
 * - 데이터 로드 (자동)
 * - 로딩/에러/빈 상태 처리 (자동)
 * - 레이아웃 (자동)
 */
const MyWidget = ({ widget, user }) => {
    // ========== 비즈니스 로직 시작 ==========
    // useWidget 훅이 모든 공통 처리 담당
    const {
        data,
        loading,
        error,
        isEmpty,
        refresh
    } = useWidget(widget, user, {
        immediate: true,
        cache: true
    });
    
    // 데이터 변환 (비즈니스 로직)
    const transformedData = data ? data.map(item => ({
        ...item,
        displayName: `${item.name} (${item.role})`
    })) : [];
    // ========== 비즈니스 로직 끝 ==========
    
    // 렌더링 로직만 작성
    const renderContent = () => {
        if (isEmpty) {
            return <div>데이터가 없습니다.</div>;
        }
        
        return (
            <ul>
                {transformedData.map(item => (
                    <li key={item.id}>{item.displayName}</li>
                ))}
            </ul>
        );
    };
    
    return (
        <BaseWidget
            widget={widget}
            user={user}
            loading={loading}
            error={error}
            isEmpty={isEmpty}
            onRefresh={refresh}
        >
            {renderContent()}
        </BaseWidget>
    );
};

export default MyWidget;
```

### 6. 모달 컴포넌트 템플릿

#### 기본 모달 템플릿
```javascript
import BaseModal from '../common/modals/BaseModal';
import { MGForm, MGFormInput } from '../common/MGForm';
import { Button } from '../ui/Button/Button';
import { apiPost } from '../../utils/ajax';

/**
 * 모달 컴포넌트 템플릿
 * 
 * 기능:
 * - 모달 열기/닫기 (자동)
 * - ESC 키 처리 (자동)
 * - 배경 클릭 처리 (자동)
 */
const MyModal = ({ isOpen, onClose, onSuccess }) => {
    // ========== 비즈니스 로직 시작 ==========
    const [formData, setFormData] = useState({
        name: '',
        email: ''
    });
    const [loading, setLoading] = useState(false);
    
    const handleSubmit = async (e) => {
        e.preventDefault();
        
        setLoading(true);
        try {
            await apiPost('/api/v1/items', formData);
            notificationManager.success('생성되었습니다.');
            onSuccess?.();
            onClose();
            setFormData({ name: '', email: '' }); // 폼 초기화
        } catch (err) {
            notificationManager.error('생성에 실패했습니다.');
        } finally {
            setLoading(false);
        }
    };
    // ========== 비즈니스 로직 끝 ==========
    
    return (
        <BaseModal
            isOpen={isOpen}
            onClose={onClose}
            title="생성"
            size="medium"
        >
            <MGForm onSubmit={handleSubmit} loading={loading}>
                <MGFormInput
                    label="이름"
                    name="name"
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({
                        ...prev,
                        name: e.target.value
                    }))}
                    required
                />
                
                <MGFormInput
                    label="이메일"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData(prev => ({
                        ...prev,
                        email: e.target.value
                    }))}
                    required
                />
                
                <div className="modal-actions">
                    <Button
                        type="submit"
                        variant="primary"
                        loading={loading}
                    >
                        생성
                    </Button>
                    
                    <Button
                        type="button"
                        variant="secondary"
                        onClick={onClose}
                    >
                        취소
                    </Button>
                </div>
            </MGForm>
        </BaseModal>
    );
};

export default MyModal;
```

---

## ✅ 템플릿 사용 체크리스트

### 새 컴포넌트 작성 시

- [ ] 적절한 템플릿 선택 (페이지/리스트/폼/상세/위젯/모달)
- [ ] 템플릿 import 및 사용
- [ ] 비즈니스 로직만 작성
- [ ] 공통 처리 (로딩/에러 등)는 템플릿에 위임
- [ ] 표준 컴포넌트 사용 (Button, Form 등)
- [ ] 반응형 레이아웃은 템플릿에 위임

### 템플릿별 확인 사항

#### 페이지 템플릿
- [ ] SimpleLayout 사용
- [ ] MGSection, MGContainer 사용
- [ ] 비즈니스 로직만 작성

#### 리스트 템플릿
- [ ] MGTable 또는 DataTable 사용
- [ ] 로딩/에러/빈 상태 처리 확인
- [ ] 컬럼 정의만 작성

#### 폼 템플릿
- [ ] MGForm 사용
- [ ] MGFormInput, MGFormSelect 등 사용
- [ ] 유효성 검사 로직만 작성

#### 위젯 템플릿
- [ ] BaseWidget 사용
- [ ] useWidget 훅 사용
- [ ] 데이터 변환 로직만 작성

---

## 🚫 금지 사항

### 1. 템플릿 없이 처음부터 작성 금지

```javascript
// ❌ 금지: 템플릿 없이 처음부터 작성
const MyPage = () => {
    return (
        <div>
            <div>
                <div>
                    {/* 레이아웃 구조 직접 작성 */}
                </div>
            </div>
        </div>
    );
};

// ✅ 권장: 템플릿 사용
const MyPage = () => {
    return (
        <SimpleLayout title="페이지 제목">
            {/* 비즈니스 로직만 작성 */}
        </SimpleLayout>
    );
};
```

### 2. 공통 처리 중복 작성 금지

```javascript
// ❌ 금지: 공통 처리 중복 작성
const MyComponent = () => {
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    
    // 로딩 UI 직접 작성
    if (loading) {
        return <div>로딩 중...</div>;
    }
    
    // 에러 UI 직접 작성
    if (error) {
        return <div>에러 발생</div>;
    }
    
    // ...
};

// ✅ 권장: 템플릿에 위임
const MyComponent = () => {
    const { loading, error } = useWidget(...);
    
    return (
        <BaseWidget loading={loading} error={error}>
            {/* 내용 */}
        </BaseWidget>
    );
};
```

### 3. 레이아웃 구조 직접 작성 금지

```javascript
// ❌ 금지: 레이아웃 구조 직접 작성
const MyPage = () => {
    return (
        <div className="layout">
            <header>
                <div className="header-content">
                    {/* 헤더 구조 직접 작성 */}
                </div>
            </header>
            <main>
                {/* 메인 구조 직접 작성 */}
            </main>
        </div>
    );
};

// ✅ 권장: 템플릿 사용
const MyPage = () => {
    return (
        <SimpleLayout title="페이지 제목">
            {/* 내용만 작성 */}
        </SimpleLayout>
    );
};
```

---

## 💡 베스트 프랙티스

### 1. 템플릿 선택 가이드

| 컴포넌트 타입 | 사용 템플릿 |
|-------------|-----------|
| 일반 페이지 | `SimpleLayout` + `MGSection` + `MGContainer` |
| 목록 페이지 | `SimpleLayout` + `MGTable` 또는 `DataTable` |
| 폼 페이지 | `SimpleLayout` + `MGForm` |
| 상세 페이지 | `SimpleLayout` + `MGCard` |
| 대시보드 위젯 | `BaseWidget` + `useWidget` 훅 |
| 모달 | `BaseModal` + `MGForm` |

### 2. 비즈니스 로직 분리

```javascript
// ✅ 권장: 비즈니스 로직 분리
const MyPage = () => {
    // 1. 상태 관리
    const [data, setData] = useState([]);
    
    // 2. 데이터 로드
    useEffect(() => {
        loadData();
    }, []);
    
    // 3. 이벤트 핸들러
    const handleAction = async () => {
        // 비즈니스 로직
    };
    
    // 4. 렌더링
    return (
        <Template>
            {/* UI 구조는 템플릿에 위임 */}
        </Template>
    );
};
```

### 3. 템플릿 확장

```javascript
// ✅ 권장: 템플릿을 확장하여 사용
const ExtendedPage = () => {
    return (
        <SimpleLayout title="페이지 제목">
            <MGSection variant="default" padding="medium">
                <MGContainer size="xl">
                    {/* 추가 섹션 */}
                    <MGSection variant="elevated" padding="small">
                        {/* 내용 */}
                    </MGSection>
                </MGContainer>
            </MGSection>
        </SimpleLayout>
    );
};
```

---

## ⏳ 공통 로딩바 표준

### 1. 표준 로딩 컴포넌트 사용 필수
```
모든 로딩 UI는 UnifiedLoading 컴포넌트 사용
```

**원칙**:
- ✅ `UnifiedLoading` 컴포넌트 사용
- ✅ 하드코딩된 로딩바 금지
- ✅ 일관된 로딩 UI 제공
- ❌ `<div className="mg-loading">로딩중...</div>` 직접 작성 금지
- ❌ 커스텀 로딩 컴포넌트 작성 금지

### 2. 로딩바 사용 패턴

#### 페이지 로딩
```javascript
import UnifiedLoading from '../common/UnifiedLoading';
import SimpleLayout from '../layout/SimpleLayout';

const MyPage = () => {
    const [loading, setLoading] = useState(true);
    
    return (
        <SimpleLayout title="페이지 제목">
            {loading ? (
                <UnifiedLoading 
                    type="page"
                    text="데이터를 불러오는 중..."
                    variant="pulse"
                />
            ) : (
                <div>페이지 내용</div>
            )}
        </SimpleLayout>
    );
};
```

#### 전체 화면 로딩
```javascript
import UnifiedLoading from '../common/UnifiedLoading';

const MyPage = () => {
    const [loading, setLoading] = useState(true);
    
    if (loading) {
        return (
            <UnifiedLoading 
                type="fullscreen"
                text="페이지를 불러오는 중..."
                variant="spinner"
                size="large"
            />
        );
    }
    
    return <div>페이지 내용</div>;
};
```

#### 인라인 로딩
```javascript
import UnifiedLoading from '../common/UnifiedLoading';

const MyComponent = () => {
    const [loading, setLoading] = useState(false);
    
    return (
        <div>
            {loading ? (
                <UnifiedLoading 
                    type="inline"
                    text="로딩 중..."
                    variant="dots"
                />
            ) : (
                <div>내용</div>
            )}
        </div>
    );
};
```

#### 버튼 로딩 (Button 컴포넌트 사용)
```javascript
import { Button } from '../ui/Button/Button';

const SubmitButton = () => {
    const [loading, setLoading] = useState(false);
    
    return (
        <Button
            variant="primary"
            loading={loading}
            loadingText="저장 중..."
            onClick={handleSubmit}
        >
            저장
        </Button>
    );
};
```

### 3. 로딩바 Variant

```javascript
// Spinner (기본)
<UnifiedLoading variant="spinner" text="로딩 중..." />

// Dots
<UnifiedLoading variant="dots" text="로딩 중..." />

// Pulse
<UnifiedLoading variant="pulse" text="로딩 중..." />

// Bars
<UnifiedLoading variant="bars" text="로딩 중..." />
```

### 4. 로딩바 금지 사항

#### 하드코딩된 로딩 HTML 작성 금지
```javascript
// ❌ 금지: 하드코딩된 로딩 HTML
{loading && (
    <div className="mg-loading">로딩중...</div>
)}

// ✅ 권장: 표준 컴포넌트 사용
{loading && (
    <UnifiedLoading 
        text="로딩 중..." 
        type="inline"
    />
)}
```

#### 커스텀 로딩 컴포넌트 작성 금지
```javascript
// ❌ 금지: 커스텀 로딩 컴포넌트
const CustomLoading = () => {
    return <div className="custom-spinner">로딩...</div>;
};

// ✅ 권장: 표준 컴포넌트 사용
import UnifiedLoading from '../common/UnifiedLoading';
```

### 5. 템플릿별 로딩 처리

#### 페이지 템플릿 - 로딩 처리
```javascript
<SimpleLayout title="페이지 제목">
    {loading ? (
        <UnifiedLoading type="page" text="로딩 중..." />
    ) : (
        <div>내용</div>
    )}
</SimpleLayout>
```

#### 리스트 템플릿 - 로딩 처리
```javascript
<MGTable
    columns={columns}
    data={items}
    loading={loading}  // MGTable이 내부적으로 UnifiedLoading 사용
    error={error}
/>
```

#### 위젯 템플릿 - 로딩 처리
```javascript
<BaseWidget
    widget={widget}
    loading={loading}  // BaseWidget이 내부적으로 UnifiedLoading 사용
    error={error}
>
    {/* 내용 */}
</BaseWidget>
```

---

## 📞 문의

컴포넌트 템플릿 표준 관련 문의:
- 프론트엔드 팀
- 아키텍처 팀

**최종 업데이트**: 2025-12-03

